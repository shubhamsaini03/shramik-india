#include<bits/stdc++.h>
using namespace std;
vector<long long>ans;
int issort(vector<long long>B,int N){
    for(int i=1;i<N;i++){
        if(B[i]>B[i-1])
        continue;
        return 0;
    }
    return 1;
}

int Possibility (int N, int M, vector<long long> A) {
   // Write your code here
   if(N==2){
       if(A[0]<A[1])
       return 1;
       return 0;
   }
   if(N==3&&M==1)
   return 1;
   if(M==0)
   return issort(A,N);int i;
   for( i=0;i<N&&M;i++){
       if(A[i]<A[i+1]&&i<N-1)
       {
           ans[it]=A[i];it++;
       }
       else{
           if((N-i-1)<3)
           return 1;
           if(A[i]<(A[i+1]+A[i+2]+A[i+3])){
               ans[it]=A[i];it++;
               ans[it]=A[i+1]+A[i+2]+A[i+3];it++;i+=3;M--;
           }
       }
   }
   for(int j=i;j<N;j++){
       ans.push_back(A[j]);
   }
   int n=ans.size();
   return issort(ans,n);
   
}

int main() {

    ios::sync_with_stdio(0);
    cin.tie(0);
    int T;
    cin >> T;
    for(int t_i = 0; t_i < T; t_i++)
    {
        int N;
        cin >> N;
        int M;
        cin >> M;
        vector<long long> A(N);
        for(int i_A = 0; i_A < N; i_A++)
        {
        	cin >> A[i_A];
        }

        int out_;
        out_ = Possibility(N, M, A);
        cout << out_;
        cout << "\n";
    }
}